package restaurant;

import java.sql.*;

public class MySQLConnection{

    private Connection con;
    private Statement st;
    private ResultSet  rs;

     static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch(ClassNotFoundException ex) {
			System.out.println("Unable to load MySQL Driver"+ex);
		}
	}
    public MySQLConnection() {
        try {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/first2?useTimezone=true&serverTimezone=UTC", "root","");
            st=con.createStatement();
        } catch (Exception e) {
            System.out.println(e);
        }
     }
    public String getdata()
    {  String show = null;
        try {
           String query="SELECT * FROM signin";
           rs=st.executeQuery(query);
            System.out.println("DATA FROM DATA-BASE ");
while(rs.next())
{   String id=rs.getString("id");
    String nam=rs.getString("username");
    String Password=rs.getString("Password");
   
 show="\n\n\n"+id+"\n\n\n"+nam+"\n\n\n"+Password;
return show;
}
return "yhn hun";

            
        
            
        } catch (Exception e) {
                System.out.println(e);
        return  "no";
        }
        
    }
 
    public void Adddata(String username,String password)
    { String show = null;
        try {
                       String query="INSERT INTO signin(username,password) VALUES('"+username+"','"+password+"')";
                       int a =st.executeUpdate(query);
                       
        } catch (Exception e) {
            System.out.println(e);
        }    
    }
    public void AddReport(String name,String topic,String dic)
    { try {
       int a=st.executeUpdate("INSERT INTO report1(rpname,topic,dic) VALUES('"+name+"','"+topic+"','"+dic+"')");
            
        } catch (Exception e) {
                System.out.println(e);
        }
        
        
    }
    public void Additem(String name ,double price,double quantity)
    {  try {
           int a= st.executeUpdate("Insert into additem2(proname,price,quantity) Values( '"+name+"','"+price+"','"+quantity+"')");
        } catch (Exception e) {
                System.out.println(e);
        }
    
    
    }
    public void updateitem(String proname,double price,double quantity,int id)
    { try {
 int a=st.executeUpdate("UPDATE additem2 Set proname='"+proname+"', price='"+price+"',quantity='"+quantity+"' where id='"+id+"'");           
        } catch (Exception e) {
                System.out.println(e);
        }

        
    }
    
    public void UserAdddata(String username,String name,String Question,String Answer,String Password,String Address)
    { String show = null;
        try {
                       String query="INSERT INTO signuo1(username,name,Question,Answer,Password,Address) VALUES('"+username+"', '"+name+"','"+Question+"','"+Answer+"','"+Password+"','"+Address+"' )";
                       int a =st.executeUpdate(query);
                       
        } catch (Exception e) {
            System.out.println(e);
        }
    }
     public void AdminAdddata(String username,String name,String Question,String Answer,String Password,String Address,String Rank)
    { String show = null;
        try {
                       String query="INSERT INTO adminsignup(username,name,Security,answer,password,address,rank) VALUES('"+username+"', '"+name+"','"+Question+"','"+Answer+"','"+Password+"','"+Address+"','"+Rank+"' )";
                       int a =st.executeUpdate(query);
                       
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
